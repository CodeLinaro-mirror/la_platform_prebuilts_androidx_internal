/*
 * Copyright 2022 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.wear.tiles.material;

import android.content.Context;

import androidx.annotation.IntRange;
import androidx.annotation.RestrictTo;
import androidx.annotation.RestrictTo.Scope;
import androidx.wear.protolayout.expression.Fingerprint;
import androidx.wear.protolayout.proto.LayoutElementProto;
import androidx.wear.protolayout.proto.ModifiersProto;

import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

/**
 * Tiles component {@link Text} that represents text object holding any information.
 *
 * <p>There are pre-built typography styles that can be obtained from constants in {@link
 * androidx.wear.tiles.LayoutElementBuilders.FontStyle}.
 *
 * <p>When accessing the contents of a container for testing, note that this element can't be simply
 * casted back to the original type, i.e.:
 *
 * <pre>{@code
 * Text text = new Text...
 * Box box = new Box.Builder().addContent(text).build();
 *
 * Text myText = (Text) box.getContents().get(0);
 * }</pre>
 *
 * will fail.
 *
 * <p>To be able to get {@link Text} object from any layout element, {@link #fromLayoutElement}
 * method should be used, i.e.:
 *
 * <pre>{@code
 * Text myText = Text.fromLayoutElement(box.getContents().get(0));
 * }</pre>
 *
 * @deprecated Use the new class {@link androidx.wear.protolayout.material.Text} which provides the
 *     same API and functionality.
 */
@Deprecated
@SuppressWarnings("deprecation")
public class Text implements androidx.wear.tiles.LayoutElementBuilders.LayoutElement {
    /**
     * Tool tag for Metadata in androidx.wear.tiles.ModifiersBuilders.Modifiers, so we know that
     * Text is actually a Material Text.
     */
    static final String METADATA_TAG = "TXT";

    private final androidx.wear.tiles.LayoutElementBuilders.@NonNull Text mText;

    Text(androidx.wear.tiles.LayoutElementBuilders.@NonNull Text mText) {
        this.mText = mText;
    }

    /** Builder class for {@link Text}. */
    public static final class Builder
            implements androidx.wear.tiles.LayoutElementBuilders.LayoutElement.Builder {
        private final @NonNull Context mContext;
        private @NonNull String mTextContent = "";

        private androidx.wear.tiles.ColorBuilders.@NonNull ColorProp mColor =
                androidx.wear.tiles.ColorBuilders.argb(Colors.DEFAULT.getOnPrimary());

        private @Typography.TypographyName int mTypographyName = Typography.TYPOGRAPHY_DISPLAY1;
        private boolean mItalic = false;
        private int mMaxLines = 1;
        private boolean mUnderline = false;

        @androidx.wear.tiles.LayoutElementBuilders.TextAlignment
        private int mMultilineAlignment =
                androidx.wear.tiles.LayoutElementBuilders.TEXT_ALIGN_CENTER;

        private androidx.wear.tiles.ModifiersBuilders.@NonNull Modifiers mModifiers =
                new androidx.wear.tiles.ModifiersBuilders.Modifiers.Builder().build();

        private @androidx.wear.tiles.LayoutElementBuilders.TextOverflow int mOverflow =
                androidx.wear.tiles.LayoutElementBuilders.TEXT_OVERFLOW_ELLIPSIZE_END;
        private boolean mIsScalable = true;
        private @Nullable Integer mCustomWeight = null;

        /**
         * Creates a builder for {@link Text}.
         *
         * @param context The application's context.
         * @param text The text content for this component.
         */
        public Builder(@NonNull Context context, @NonNull String text) {
            mContext = context;
            mTextContent = text;
        }

        /**
         * Sets the typography for the {@link Text}. If not set, {@link
         * Typography#TYPOGRAPHY_DISPLAY1} will be used.
         */
        @SuppressWarnings("MissingGetterMatchingBuilder")
        // There is getFontStyle matching getter for this setter as the serialized format of the
        // Tiles do not allow for a direct reconstruction of the all arguments, but it has
        // androidx.wear.tiles.LayoutElementBuilders.FontStyle object of that text.
        public @NonNull Builder setTypography(@Typography.TypographyName int typography) {
            this.mTypographyName = typography;
            return this;
        }

        /**
         * Sets whether the text size will change if user has changed the default font size. If not
         * set, true will be used.
         */
        Builder setIsScalable(boolean isScalable) {
            this.mIsScalable = isScalable;
            return this;
        }

        /**
         * Sets the color for the {@link Text}. If not set, onPrimary color from the {@link
         * Colors#DEFAULT} will be used.
         */
        public @NonNull Builder setColor(
                androidx.wear.tiles.ColorBuilders.@NonNull ColorProp color) {
            this.mColor = color;
            return this;
        }

        /** Sets the text to be italic. If not set, false will be used. */
        public @NonNull Builder setItalic(boolean italic) {
            this.mItalic = italic;
            return this;
        }

        /** Sets the text to be underlined. If not set, false will be used. */
        public @NonNull Builder setUnderline(boolean underline) {
            this.mUnderline = underline;
            return this;
        }

        /** Sets the maximum lines of text. If not set, 1 will be used. */
        public @NonNull Builder setMaxLines(@IntRange(from = 1) int maxLines) {
            this.mMaxLines = maxLines;
            return this;
        }

        /**
         * Sets the multiline alignment for text within bounds of the Text element. Note that this
         * option has no effect for single line of text, and for that, alignment on the outer
         * container should be used. If not set, {@link
         * androidx.wear.tiles.LayoutElementBuilders.TextAlignment#TEXT_ALIGN_CENTER} will be used.
         */
        public @NonNull Builder setMultilineAlignment(
                @androidx.wear.tiles.LayoutElementBuilders.TextAlignment int multilineAlignment) {
            this.mMultilineAlignment = multilineAlignment;
            return this;
        }

        /** Sets the modifiers of text. */
        public @NonNull Builder setModifiers(
                androidx.wear.tiles.ModifiersBuilders.@NonNull Modifiers modifiers) {
            this.mModifiers = modifiers;
            return this;
        }

        /**
         * Sets the overflow for text. If not set, {@link
         * androidx.wear.tiles.LayoutElementBuilders.TextAlignment#TEXT_OVERFLOW_ELLIPSIZE_END} will
         * be used.
         */
        public @NonNull Builder setOverflow(
                @androidx.wear.tiles.LayoutElementBuilders.TextOverflow int overflow) {
            this.mOverflow = overflow;
            return this;
        }

        /**
         * Sets the weight of the font. If not set, default weight for the chosen Typography will be
         * used.
         */
        public @NonNull Builder setWeight(
                @androidx.wear.tiles.LayoutElementBuilders.FontWeight int weight) {
            this.mCustomWeight = weight;
            return this;
        }

        /** Constructs and returns {@link Text} with the provided content and look. */
        @Override
        public @NonNull Text build() {
            androidx.wear.tiles.LayoutElementBuilders.FontStyle.Builder fontStyleBuilder =
                    Typography.getFontStyleBuilder(mTypographyName, mContext, mIsScalable)
                            .setColor(mColor)
                            .setItalic(mItalic)
                            .setUnderline(mUnderline);
            if (mCustomWeight != null) {
                fontStyleBuilder.setWeight(mCustomWeight);
            }

            androidx.wear.tiles.LayoutElementBuilders.Text.Builder text =
                    new androidx.wear.tiles.LayoutElementBuilders.Text.Builder()
                            .setText(mTextContent)
                            .setFontStyle(fontStyleBuilder.build())
                            .setLineHeight(Typography.getLineHeightForTypography(mTypographyName))
                            .setMaxLines(mMaxLines)
                            .setMultilineAlignment(mMultilineAlignment)
                            .setModifiers(addTagToModifiers(mModifiers))
                            .setOverflow(mOverflow);
            return new Text(text.build());
        }

        static androidx.wear.tiles.ModifiersBuilders.@NonNull Modifiers addTagToModifiers(
                androidx.wear.tiles.ModifiersBuilders.Modifiers modifiers) {
            return androidx.wear.tiles.ModifiersBuilders.Modifiers.fromProto(
                    ModifiersProto.Modifiers.newBuilder(modifiers.toProto())
                            .setMetadata(
                                    new androidx.wear.tiles.ModifiersBuilders.ElementMetadata
                                                    .Builder()
                                            .setTagData(
                                                    androidx.wear.tiles.material.Helper.getTagBytes(
                                                            METADATA_TAG))
                                            .build()
                                            .toProto())
                            .build(),
                    modifiers.getFingerprint());
        }
    }

    /** Returns the text of this Text element. */
    public @NonNull String getText() {
        return androidx.wear.tiles.material.Helper.checkNotNull(
                androidx.wear.tiles.material.Helper.checkNotNull(mText.getText()).getValue());
    }

    /** Returns the color of this Text element. */
    public androidx.wear.tiles.ColorBuilders.@NonNull ColorProp getColor() {
        return androidx.wear.tiles.material.Helper.checkNotNull(
                androidx.wear.tiles.material.Helper.checkNotNull(mText.getFontStyle()).getColor());
    }

    /** Returns the font style of this Text element. */
    public androidx.wear.tiles.LayoutElementBuilders.@NonNull FontStyle getFontStyle() {
        return androidx.wear.tiles.material.Helper.checkNotNull(mText.getFontStyle());
    }

    /** Returns the line height of this Text element. */
    public float getLineHeight() {
        return androidx.wear.tiles.material.Helper.checkNotNull(mText.getLineHeight()).getValue();
    }

    /** Returns the max lines of text of this Text element. */
    public int getMaxLines() {
        return androidx.wear.tiles.material.Helper.checkNotNull(mText.getMaxLines()).getValue();
    }

    /** Returns the multiline alignment of this Text element. */
    @androidx.wear.tiles.LayoutElementBuilders.TextAlignment
    public int getMultilineAlignment() {
        return androidx.wear.tiles.material.Helper.checkNotNull(mText.getMultilineAlignment())
                .getValue();
    }

    /** Returns the modifiers of this Text element. */
    public androidx.wear.tiles.ModifiersBuilders.@NonNull Modifiers getModifiers() {
        return androidx.wear.tiles.material.Helper.checkNotNull(mText.getModifiers());
    }

    /** Returns the overflow of this Text element. */
    @androidx.wear.tiles.LayoutElementBuilders.TextOverflow
    public int getOverflow() {
        return androidx.wear.tiles.material.Helper.checkNotNull(mText.getOverflow()).getValue();
    }

    /** Returns the overflow of this Text element. */
    @androidx.wear.tiles.LayoutElementBuilders.FontWeight
    public int getWeight() {
        return androidx.wear.tiles.material.Helper.checkNotNull(
                        androidx.wear.tiles.material.Helper.checkNotNull(mText.getFontStyle())
                                .getWeight())
                .getValue();
    }

    /** Returns whether the Text is in italic. */
    public boolean isItalic() {
        return androidx.wear.tiles.material.Helper.checkNotNull(
                        androidx.wear.tiles.material.Helper.checkNotNull(mText.getFontStyle())
                                .getItalic())
                .getValue();
    }

    /** Returns whether the Text is underlined. */
    public boolean isUnderline() {
        return androidx.wear.tiles.material.Helper.checkNotNull(
                        androidx.wear.tiles.material.Helper.checkNotNull(mText.getFontStyle())
                                .getUnderline())
                .getValue();
    }

    /** Returns metadata tag set to this Text, which should be {@link #METADATA_TAG}. */
    @NonNull String getMetadataTag() {
        return androidx.wear.tiles.material.Helper.getMetadataTagName(
                androidx.wear.tiles.material.Helper.checkNotNull(
                        androidx.wear.tiles.material.Helper.checkNotNull(getModifiers())
                                .getMetadata()));
    }

    /**
     * Returns Material Text object from the given
     * androidx.wear.tiles.LayoutElementBuilders.LayoutElement (e.g. one retrieved from a
     * container's content with {@code container.getContents().get(index)}) if that element can be
     * converted to Material Text. Otherwise, it will return null.
     */
    public static @Nullable Text fromLayoutElement(
            androidx.wear.tiles.LayoutElementBuilders.@NonNull LayoutElement element) {
        if (element instanceof Text) {
            return (Text) element;
        }
        if (!(element instanceof androidx.wear.tiles.LayoutElementBuilders.Text)) {
            return null;
        }
        androidx.wear.tiles.LayoutElementBuilders.Text textElement =
                (androidx.wear.tiles.LayoutElementBuilders.Text) element;
        if (!androidx.wear.tiles.material.Helper.checkTag(
                textElement.getModifiers(), METADATA_TAG)) {
            return null;
        }
        // Now we are sure that this element is a Material Text.
        return new Text(textElement);
    }

    @Override
    @RestrictTo(Scope.LIBRARY_GROUP)
    public LayoutElementProto.@NonNull LayoutElement toLayoutElementProto() {
        return mText.toLayoutElementProto();
    }

    @RestrictTo(Scope.LIBRARY_GROUP)
    @Override
    public @Nullable Fingerprint getFingerprint() {
        return mText.getFingerprint();
    }
}
