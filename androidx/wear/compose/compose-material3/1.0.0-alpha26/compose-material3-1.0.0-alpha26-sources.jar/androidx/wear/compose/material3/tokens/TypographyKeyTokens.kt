/*
 * Copyright 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// VERSION: v0_71
// GENERATED CODE - DO NOT MODIFY BY HAND

package androidx.wear.compose.material3.tokens

internal enum class TypographyKeyTokens {
    ArcLarge,
    ArcMedium,
    ArcSmall,
    BodyExtraSmall,
    BodyLarge,
    BodyMedium,
    BodySmall,
    DisplayLarge,
    DisplayMedium,
    DisplaySmall,
    LabelLarge,
    LabelMedium,
    LabelSmall,
    NumeralExtraLarge,
    NumeralExtraSmall,
    NumeralLarge,
    NumeralMedium,
    NumeralSmall,
    TitleLarge,
    TitleMedium,
    TitleSmall,
}
