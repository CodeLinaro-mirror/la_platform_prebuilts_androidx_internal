/*
 * Copyright 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.room.compiler.codegen.impl

import androidx.room.compiler.codegen.XAnnotationSpec
import androidx.room.compiler.codegen.XCodeBlock
import androidx.room.compiler.codegen.XSpec
import androidx.room.compiler.codegen.java.JavaAnnotationSpec
import androidx.room.compiler.codegen.kotlin.KotlinAnnotationSpec

internal class XAnnotationSpecImpl(
    val java: JavaAnnotationSpec,
    val kotlin: KotlinAnnotationSpec,
) : XSpec(), XAnnotationSpec {

    internal class Builder(
        val java: JavaAnnotationSpec.Builder,
        val kotlin: KotlinAnnotationSpec.Builder,
    ) : XSpec.Builder(), XAnnotationSpec.Builder {
        private val delegates: List<XAnnotationSpec.Builder> = listOf(java, kotlin)

        override fun addMember(name: String, code: XCodeBlock) = apply {
            delegates.forEach { it.addMember(name, code) }
        }

        override fun build() = XAnnotationSpecImpl(java.build(), kotlin.build())
    }
}
