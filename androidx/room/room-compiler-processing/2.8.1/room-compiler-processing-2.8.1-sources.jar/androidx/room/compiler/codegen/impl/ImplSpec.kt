/*
 * Copyright 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.room.compiler.codegen.impl

import androidx.room.compiler.codegen.XSpec

internal abstract class ImplSpec<JavaT, KotlinT> : XSpec() {
    abstract val java: JavaT
    abstract val kotlin: KotlinT

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is ImplSpec<JavaT, KotlinT>) return false
        if (java != other.java) return false
        if (kotlin != other.kotlin) return false
        return true
    }

    override fun hashCode(): Int {
        return java.hashCode()
    }
}
