/*
 * Copyright 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.compose.material.icons.filled

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.materialIcon
import androidx.compose.material.icons.materialPath
import androidx.compose.ui.graphics.vector.ImageVector

public val Icons.Filled.CameraFront: ImageVector
    get() {
        if (_cameraFront != null) {
            return _cameraFront!!
        }
        _cameraFront = materialIcon(name = "Filled.CameraFront") {
            materialPath {
                moveTo(10.0f, 20.0f)
                lineTo(5.0f, 20.0f)
                verticalLineToRelative(2.0f)
                horizontalLineToRelative(5.0f)
                verticalLineToRelative(2.0f)
                lineToRelative(3.0f, -3.0f)
                lineToRelative(-3.0f, -3.0f)
                verticalLineToRelative(2.0f)
                close()
                moveTo(14.0f, 20.0f)
                verticalLineToRelative(2.0f)
                horizontalLineToRelative(5.0f)
                verticalLineToRelative(-2.0f)
                horizontalLineToRelative(-5.0f)
                close()
                moveTo(12.0f, 8.0f)
                curveToRelative(1.1f, 0.0f, 2.0f, -0.9f, 2.0f, -2.0f)
                reflectiveCurveToRelative(-0.9f, -2.0f, -2.0f, -2.0f)
                reflectiveCurveToRelative(-1.99f, 0.9f, -1.99f, 2.0f)
                reflectiveCurveTo(10.9f, 8.0f, 12.0f, 8.0f)
                close()
                moveTo(17.0f, 0.0f)
                lineTo(7.0f, 0.0f)
                curveTo(5.9f, 0.0f, 5.0f, 0.9f, 5.0f, 2.0f)
                verticalLineToRelative(14.0f)
                curveToRelative(0.0f, 1.1f, 0.9f, 2.0f, 2.0f, 2.0f)
                horizontalLineToRelative(10.0f)
                curveToRelative(1.1f, 0.0f, 2.0f, -0.9f, 2.0f, -2.0f)
                lineTo(19.0f, 2.0f)
                curveToRelative(0.0f, -1.1f, -0.9f, -2.0f, -2.0f, -2.0f)
                close()
                moveTo(7.0f, 2.0f)
                horizontalLineToRelative(10.0f)
                verticalLineToRelative(10.5f)
                curveToRelative(0.0f, -1.67f, -3.33f, -2.5f, -5.0f, -2.5f)
                reflectiveCurveToRelative(-5.0f, 0.83f, -5.0f, 2.5f)
                lineTo(7.0f, 2.0f)
                close()
            }
        }
        return _cameraFront!!
    }

private var _cameraFront: ImageVector? = null
