/*
 * Copyright 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.compose.material.icons.automirrored.outlined

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.materialIcon
import androidx.compose.material.icons.materialPath
import androidx.compose.ui.graphics.vector.ImageVector

public val Icons.AutoMirrored.Outlined.Shortcut: ImageVector
    get() {
        if (_shortcut != null) {
            return _shortcut!!
        }
        _shortcut = materialIcon(name = "AutoMirrored.Outlined.Shortcut", autoMirror = true) {
            materialPath {
                moveTo(15.0f, 5.0f)
                lineToRelative(-1.41f, 1.41f)
                lineTo(15.0f, 7.83f)
                lineTo(17.17f, 10.0f)
                horizontalLineTo(8.0f)
                curveToRelative(-2.76f, 0.0f, -5.0f, 2.24f, -5.0f, 5.0f)
                verticalLineToRelative(4.0f)
                horizontalLineToRelative(2.0f)
                verticalLineToRelative(-4.0f)
                curveToRelative(0.0f, -1.65f, 1.35f, -3.0f, 3.0f, -3.0f)
                horizontalLineToRelative(9.17f)
                lineTo(15.0f, 14.17f)
                lineToRelative(-1.41f, 1.41f)
                lineTo(15.0f, 17.0f)
                lineToRelative(6.0f, -6.0f)
                lineTo(15.0f, 5.0f)
                close()
            }
        }
        return _shortcut!!
    }

private var _shortcut: ImageVector? = null
