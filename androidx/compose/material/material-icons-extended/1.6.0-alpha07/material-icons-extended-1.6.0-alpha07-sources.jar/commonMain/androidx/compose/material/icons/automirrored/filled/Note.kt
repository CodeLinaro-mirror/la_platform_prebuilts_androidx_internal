/*
 * Copyright 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.compose.material.icons.automirrored.filled

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.materialIcon
import androidx.compose.material.icons.materialPath
import androidx.compose.ui.graphics.vector.ImageVector

public val Icons.AutoMirrored.Filled.Note: ImageVector
    get() {
        if (_note != null) {
            return _note!!
        }
        _note = materialIcon(name = "AutoMirrored.Filled.Note", autoMirror = true) {
            materialPath {
                moveTo(22.0f, 10.0f)
                lineToRelative(-6.0f, -6.0f)
                lineTo(4.0f, 4.0f)
                curveToRelative(-1.1f, 0.0f, -2.0f, 0.9f, -2.0f, 2.0f)
                verticalLineToRelative(12.01f)
                curveToRelative(0.0f, 1.1f, 0.9f, 1.99f, 2.0f, 1.99f)
                lineToRelative(16.0f, -0.01f)
                curveToRelative(1.1f, 0.0f, 2.0f, -0.89f, 2.0f, -1.99f)
                verticalLineToRelative(-8.0f)
                close()
                moveTo(15.0f, 5.5f)
                lineToRelative(5.5f, 5.5f)
                lineTo(15.0f, 11.0f)
                lineTo(15.0f, 5.5f)
                close()
            }
        }
        return _note!!
    }

private var _note: ImageVector? = null
