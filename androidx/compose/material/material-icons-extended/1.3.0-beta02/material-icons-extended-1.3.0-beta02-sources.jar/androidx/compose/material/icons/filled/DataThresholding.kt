/*
 * Copyright 2022 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.compose.material.icons.filled

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.materialIcon
import androidx.compose.material.icons.materialPath
import androidx.compose.ui.graphics.vector.ImageVector

public val Icons.Filled.DataThresholding: ImageVector
    get() {
        if (_dataThresholding != null) {
            return _dataThresholding!!
        }
        _dataThresholding = materialIcon(name = "Filled.DataThresholding") {
            materialPath {
                moveTo(19.0f, 3.0f)
                horizontalLineTo(5.0f)
                curveTo(3.9f, 3.0f, 3.0f, 3.9f, 3.0f, 5.0f)
                verticalLineToRelative(14.0f)
                curveToRelative(0.0f, 1.1f, 0.9f, 2.0f, 2.0f, 2.0f)
                horizontalLineToRelative(14.0f)
                curveToRelative(1.1f, 0.0f, 2.0f, -0.9f, 2.0f, -2.0f)
                verticalLineTo(5.0f)
                curveTo(21.0f, 3.9f, 20.1f, 3.0f, 19.0f, 3.0f)
                close()
                moveTo(10.67f, 8.17f)
                lineToRelative(2.0f, 2.0f)
                lineToRelative(3.67f, -3.67f)
                lineToRelative(1.41f, 1.41f)
                lineTo(12.67f, 13.0f)
                lineToRelative(-2.0f, -2.0f)
                lineToRelative(-3.0f, 3.0f)
                lineToRelative(-1.41f, -1.41f)
                lineTo(10.67f, 8.17f)
                close()
                moveTo(5.0f, 16.0f)
                horizontalLineToRelative(1.72f)
                lineTo(5.0f, 17.72f)
                verticalLineTo(16.0f)
                close()
                moveTo(5.84f, 19.0f)
                lineToRelative(3.0f, -3.0f)
                horizontalLineToRelative(1.83f)
                lineToRelative(-3.0f, 3.0f)
                horizontalLineTo(5.84f)
                close()
                moveTo(9.8f, 19.0f)
                lineToRelative(3.0f, -3.0f)
                horizontalLineToRelative(1.62f)
                lineToRelative(-3.0f, 3.0f)
                horizontalLineTo(9.8f)
                close()
                moveTo(13.53f, 19.0f)
                lineToRelative(3.0f, -3.0f)
                horizontalLineToRelative(1.62f)
                lineToRelative(-3.0f, 3.0f)
                horizontalLineTo(13.53f)
                close()
                moveTo(19.0f, 19.0f)
                horizontalLineToRelative(-1.73f)
                lineTo(19.0f, 17.27f)
                verticalLineTo(19.0f)
                close()
            }
        }
        return _dataThresholding!!
    }

private var _dataThresholding: ImageVector? = null
