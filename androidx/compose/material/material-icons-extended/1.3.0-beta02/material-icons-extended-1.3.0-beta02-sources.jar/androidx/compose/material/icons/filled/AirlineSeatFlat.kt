/*
 * Copyright 2022 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.compose.material.icons.filled

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.materialIcon
import androidx.compose.material.icons.materialPath
import androidx.compose.ui.graphics.vector.ImageVector

public val Icons.Filled.AirlineSeatFlat: ImageVector
    get() {
        if (_airlineSeatFlat != null) {
            return _airlineSeatFlat!!
        }
        _airlineSeatFlat = materialIcon(name = "Filled.AirlineSeatFlat") {
            materialPath {
                moveTo(22.0f, 11.0f)
                verticalLineToRelative(2.0f)
                lineTo(9.0f, 13.0f)
                lineTo(9.0f, 7.0f)
                horizontalLineToRelative(9.0f)
                curveToRelative(2.21f, 0.0f, 4.0f, 1.79f, 4.0f, 4.0f)
                close()
                moveTo(2.0f, 14.0f)
                verticalLineToRelative(2.0f)
                horizontalLineToRelative(6.0f)
                verticalLineToRelative(2.0f)
                horizontalLineToRelative(8.0f)
                verticalLineToRelative(-2.0f)
                horizontalLineToRelative(6.0f)
                verticalLineToRelative(-2.0f)
                lineTo(2.0f, 14.0f)
                close()
                moveTo(7.14f, 12.1f)
                curveToRelative(1.16f, -1.19f, 1.14f, -3.08f, -0.04f, -4.24f)
                curveToRelative(-1.19f, -1.16f, -3.08f, -1.14f, -4.24f, 0.04f)
                curveToRelative(-1.16f, 1.19f, -1.14f, 3.08f, 0.04f, 4.24f)
                curveToRelative(1.19f, 1.16f, 3.08f, 1.14f, 4.24f, -0.04f)
                close()
            }
        }
        return _airlineSeatFlat!!
    }

private var _airlineSeatFlat: ImageVector? = null
