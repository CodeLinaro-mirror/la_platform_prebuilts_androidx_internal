/*
 * Copyright 2022 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.compose.material.icons.filled

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.materialIcon
import androidx.compose.material.icons.materialPath
import androidx.compose.ui.graphics.vector.ImageVector

public val Icons.Filled.CastForEducation: ImageVector
    get() {
        if (_castForEducation != null) {
            return _castForEducation!!
        }
        _castForEducation = materialIcon(name = "Filled.CastForEducation") {
            materialPath {
                moveTo(21.0f, 3.0f)
                horizontalLineTo(3.0f)
                curveTo(1.9f, 3.0f, 1.0f, 3.9f, 1.0f, 5.0f)
                verticalLineToRelative(3.0f)
                horizontalLineToRelative(2.0f)
                verticalLineTo(5.0f)
                horizontalLineToRelative(18.0f)
                verticalLineToRelative(14.0f)
                horizontalLineToRelative(-7.0f)
                verticalLineToRelative(2.0f)
                horizontalLineToRelative(7.0f)
                curveToRelative(1.1f, 0.0f, 2.0f, -0.9f, 2.0f, -2.0f)
                verticalLineTo(5.0f)
                curveTo(23.0f, 3.9f, 22.1f, 3.0f, 21.0f, 3.0f)
                close()
                moveTo(1.0f, 18.0f)
                verticalLineToRelative(3.0f)
                horizontalLineToRelative(3.0f)
                curveTo(4.0f, 19.34f, 2.66f, 18.0f, 1.0f, 18.0f)
                close()
                moveTo(1.0f, 14.0f)
                verticalLineToRelative(2.0f)
                curveToRelative(2.76f, 0.0f, 5.0f, 2.24f, 5.0f, 5.0f)
                horizontalLineToRelative(2.0f)
                curveTo(8.0f, 17.13f, 4.87f, 14.0f, 1.0f, 14.0f)
                close()
                moveTo(1.0f, 10.0f)
                verticalLineToRelative(2.0f)
                curveToRelative(4.97f, 0.0f, 9.0f, 4.03f, 9.0f, 9.0f)
                horizontalLineToRelative(2.0f)
                curveTo(12.0f, 14.92f, 7.07f, 10.0f, 1.0f, 10.0f)
                close()
                moveTo(11.0f, 11.09f)
                verticalLineToRelative(2.0f)
                lineTo(14.5f, 15.0f)
                lineToRelative(3.5f, -1.91f)
                verticalLineToRelative(-2.0f)
                lineTo(14.5f, 13.0f)
                lineTo(11.0f, 11.09f)
                close()
                moveTo(14.5f, 6.0f)
                lineTo(9.0f, 9.0f)
                lineToRelative(5.5f, 3.0f)
                lineTo(20.0f, 9.0f)
                lineTo(14.5f, 6.0f)
                close()
            }
        }
        return _castForEducation!!
    }

private var _castForEducation: ImageVector? = null
