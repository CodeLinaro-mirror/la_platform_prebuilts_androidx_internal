/*
 * Copyright 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.compose.material.icons.automirrored.outlined

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.materialIcon
import androidx.compose.material.icons.materialPath
import androidx.compose.ui.graphics.vector.ImageVector

public val Icons.AutoMirrored.Outlined.SendAndArchive: ImageVector
    get() {
        if (_sendAndArchive != null) {
            return _sendAndArchive!!
        }
        _sendAndArchive = materialIcon(name = "AutoMirrored.Outlined.SendAndArchive", autoMirror =
                true) {
            materialPath {
                moveTo(11.0f, 12.0f)
                lineToRelative(-6.0f, -1.5f)
                verticalLineTo(7.01f)
                lineToRelative(8.87f, 3.73f)
                curveToRelative(0.94f, -0.47f, 2.0f, -0.75f, 3.13f, -0.75f)
                curveToRelative(0.1f, 0.0f, 0.19f, 0.01f, 0.28f, 0.01f)
                lineTo(3.0f, 4.0f)
                verticalLineToRelative(16.0f)
                lineToRelative(7.0f, -2.95f)
                curveToRelative(0.0f, -0.02f, 0.0f, -0.03f, 0.0f, -0.05f)
                curveToRelative(0.0f, -0.8f, 0.14f, -1.56f, 0.39f, -2.28f)
                lineTo(5.0f, 16.99f)
                verticalLineTo(13.5f)
                lineTo(11.0f, 12.0f)
                close()
            }
            materialPath {
                moveTo(17.0f, 12.0f)
                curveToRelative(-2.76f, 0.0f, -5.0f, 2.24f, -5.0f, 5.0f)
                reflectiveCurveToRelative(2.24f, 5.0f, 5.0f, 5.0f)
                reflectiveCurveToRelative(5.0f, -2.24f, 5.0f, -5.0f)
                reflectiveCurveTo(19.76f, 12.0f, 17.0f, 12.0f)
                close()
                moveTo(17.0f, 20.0f)
                lineToRelative(-3.0f, -3.0f)
                lineToRelative(0.71f, -0.71f)
                lineToRelative(1.79f, 1.79f)
                verticalLineTo(14.0f)
                horizontalLineToRelative(1.0f)
                verticalLineToRelative(4.09f)
                lineToRelative(1.79f, -1.79f)
                lineTo(20.0f, 17.0f)
                lineTo(17.0f, 20.0f)
                close()
            }
        }
        return _sendAndArchive!!
    }

private var _sendAndArchive: ImageVector? = null
