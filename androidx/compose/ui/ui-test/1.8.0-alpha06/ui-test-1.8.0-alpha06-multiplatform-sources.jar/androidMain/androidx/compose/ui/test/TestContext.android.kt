/*
 * Copyright 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.compose.ui.test

import androidx.annotation.RequiresApi
import com.google.android.apps.common.testing.accessibility.framework.integrations.espresso.AccessibilityValidator

internal actual fun createPlatformTestContext(): PlatformTestContext = PlatformTestContext()

internal actual class PlatformTestContext(
    @get:RequiresApi(34)
    @set:RequiresApi(34)
    var accessibilityValidator: AccessibilityValidator? = null
)
