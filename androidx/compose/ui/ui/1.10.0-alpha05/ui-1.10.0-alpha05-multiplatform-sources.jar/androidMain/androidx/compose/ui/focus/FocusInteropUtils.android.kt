/*
 * Copyright 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.compose.ui.focus

import android.graphics.Rect as AndroidRect
import android.view.FocusFinder
import android.view.View
import android.view.ViewGroup
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEvent
import androidx.compose.ui.input.key.isShiftPressed
import androidx.compose.ui.input.key.key
import androidx.compose.ui.platform.AndroidComposeView
import androidx.compose.ui.unit.LayoutDirection

private val tempCoordinates = IntArray(2)
private val tempRect = AndroidRect()

/** Converts an android focus direction to a compose [focus direction][FocusDirection]. */
internal fun toFocusDirection(androidDirection: Int): FocusDirection? =
    when (androidDirection) {
        ViewGroup.FOCUS_UP -> FocusDirection.Up
        ViewGroup.FOCUS_DOWN -> FocusDirection.Down
        ViewGroup.FOCUS_LEFT -> FocusDirection.Left
        ViewGroup.FOCUS_RIGHT -> FocusDirection.Right
        ViewGroup.FOCUS_FORWARD -> FocusDirection.Next
        ViewGroup.FOCUS_BACKWARD -> FocusDirection.Previous
        else -> null
    }

/** Converts a compose [focus direction][FocusDirection] to an android focus direction. */
internal fun FocusDirection.toAndroidFocusDirection(): Int? =
    when (this) {
        FocusDirection.Up -> ViewGroup.FOCUS_UP
        FocusDirection.Down -> ViewGroup.FOCUS_DOWN
        FocusDirection.Left -> ViewGroup.FOCUS_LEFT
        FocusDirection.Right -> ViewGroup.FOCUS_RIGHT
        FocusDirection.Next -> ViewGroup.FOCUS_FORWARD
        FocusDirection.Previous -> ViewGroup.FOCUS_BACKWARD
        else -> null
    }

/** The [FocusDirection] represented by the specified keyEvent. */
internal fun KeyEvent.toFocusDirection(): FocusDirection? {
    return when (key) {
        Key.NavigatePrevious -> FocusDirection.Previous
        Key.NavigateNext -> FocusDirection.Next
        Key.Tab -> if (isShiftPressed) FocusDirection.Previous else FocusDirection.Next
        Key.DirectionRight -> FocusDirection.Right
        Key.DirectionLeft -> FocusDirection.Left
        // For the initial key input of a new composable, both up/down and page up/down will
        // trigger the composable to get focus (so the composable can handle key events to
        // move focus or scroll content). Remember, a composable can't receive key events without
        // focus.
        Key.DirectionUp,
        Key.PageUp -> FocusDirection.Up
        Key.DirectionDown,
        Key.PageDown -> FocusDirection.Down
        Key.DirectionCenter,
        Key.Enter,
        Key.NumPadEnter -> FocusDirection.Enter
        Key.Back,
        Key.Escape -> FocusDirection.Exit
        else -> null
    }
}

/** Convert an Android layout direction to a compose [layout direction][LayoutDirection]. */
internal fun toLayoutDirection(androidLayoutDirection: Int): LayoutDirection? {
    return when (androidLayoutDirection) {
        android.util.LayoutDirection.LTR -> LayoutDirection.Ltr
        android.util.LayoutDirection.RTL -> LayoutDirection.Rtl
        else -> null
    }
}

/** Returns the focus rect of the view in the current window. */
internal fun View.calculateFocusRectRelativeTo(view: View): Rect {
    getLocationInWindow(tempCoordinates)
    val xInWindow = tempCoordinates[0]
    val yInWindow = tempCoordinates[1]
    view.getLocationInWindow(tempCoordinates)
    val targetX = tempCoordinates[0]
    val targetY = tempCoordinates[1]
    val x = (xInWindow - targetX).toFloat()
    val y = (yInWindow - targetY).toFloat()
    getFocusedRect(tempRect)
    return Rect(
        x + tempRect.left,
        y + tempRect.top,
        x + tempRect.left + tempRect.width(),
        y + tempRect.top + tempRect.height(),
    )
}

internal fun View.requestInteropFocus(direction: Int?, rect: AndroidRect?): Boolean {
    return when {
        direction == null -> requestFocus()
        this !is ViewGroup -> requestFocus(direction, rect)
        isFocused -> true
        isFocusable && !hasFocus() -> requestFocus(direction, rect)
        this is AndroidComposeView -> requestFocus(direction, rect)
        rect != null ->
            FocusFinder.getInstance()
                .findNextFocusFromRect(this, rect, direction)
                ?.requestFocus(direction, rect) ?: requestFocus(direction, rect)
        else -> {
            val focusedView = if (hasFocus()) findFocus() else null
            FocusFinder.getInstance()
                .findNextFocus(this, focusedView, direction)
                ?.requestFocus(direction) ?: requestFocus(direction)
        }
    }
}
