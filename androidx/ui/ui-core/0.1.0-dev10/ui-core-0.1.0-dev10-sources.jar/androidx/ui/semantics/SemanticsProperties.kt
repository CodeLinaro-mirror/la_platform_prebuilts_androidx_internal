/*
 * Copyright 2019 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.ui.semantics

import androidx.ui.unit.Px
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

/**
 * This class defines the APIs for accessibility properties.
 */
object SemanticsProperties {
    // content description of the semantics node
    val AccessibilityLabel = object : SemanticsPropertyKey<String>("AccessibilityLabel") {
        override fun merge(existingValue: String, newValue: String): String {
            // TODO(b/138173613): Needs TextDirection, probably needs to pass both nodes
            //  to retrieve it
            return existingValue + "\n" + newValue
        }
    }

    // state description of the semantics node
    val AccessibilityValue = SemanticsPropertyKey<String>("AccessibilityValue")

    // a data structure which contains the current value and range of values
    val AccessibilityRangeInfo =
        SemanticsPropertyKey<AccessibilityRangeInfo>("AccessibilityRangeInfo")

    // whether this semantics node is enabled
    val Enabled = SemanticsPropertyKey<Boolean>("Enabled")

    // whether this semantics node is hidden
    val Hidden = SemanticsPropertyKey<Boolean>("Hidden")

    // TODO(b/151228491): TextDirection needs to be in core for platform use
    // val TextDirection = SemanticsPropertyKey<TextDirection>("TextDirection")

    // TODO(b/138172781): Move to FoundationSemanticsProperties
    val TestTag = SemanticsPropertyKey<String>("TestTag")
}

/**
 * Ths class defines keys of the actions which can be set in semantics and performed on the
 * semantics node.
 */
class SemanticsActions {
    companion object {
        // action to be performed when the node is clicked
        val OnClick = SemanticsPropertyKey<AccessibilityAction<() -> Unit>>("OnClick")

        // action to scroll to a specified position
        val ScrollTo =
            SemanticsPropertyKey<AccessibilityAction<(x: Px, y: Px) -> Unit>>("ScrollTo")

        // custom actions which are defined by app developers
        val CustomActions =
            SemanticsPropertyKey<List<AccessibilityAction<() -> Unit>>>("CustomActions")
    }
}

open class SemanticsPropertyKey<T>(
    /**
     * The name of the property.  Should be the same as the constant from which it is accessed.
     */
    val name: String
) :
    ReadWriteProperty<SemanticsPropertyReceiver, T> {
    /**
     * Subclasses that wish to implement merging should override this to output the merged value
     *
     * This implementation always throws IllegalStateException.  It should be overridden for
     * properties that can be merged.
     */
    open fun merge(existingValue: T, newValue: T): T {
        throw IllegalStateException(
            "merge function called on unmergeable property $name. " +
                    "Existing value: $existingValue, new value: $newValue. " +
                    "You may need to add a semantic boundary."
        )
    }

    /**
     * Throws [UnsupportedOperationException].  Should not be called.
     */
    // noinspection DeprecatedCallableAddReplaceWith
    // TODO(KT-32770): Re-deprecate this
    // @Deprecated(
    //     message = "You cannot retrieve a semantics property directly - " +
    //             "use one of the SemanticsConfiguration.getOr* methods instead",
    //     level = DeprecationLevel.ERROR
    // )
    // TODO(KT-6519): Remove this getter entirely
    final override fun getValue(thisRef: SemanticsPropertyReceiver, property: KProperty<*>): T {
        throw UnsupportedOperationException(
            "You cannot retrieve a semantics property directly - " +
                    "use one of the SemanticsConfiguration.getOr* methods instead"
        )
    }

    final override fun setValue(
        thisRef: SemanticsPropertyReceiver,
        property: KProperty<*>,
        value: T
    ) {
        thisRef[this] = value
    }

    override fun toString(): String {
        return "SemanticsPropertyKey: $name"
    }
}

// This needs to be in core because it needs to be accessible from platform
data class AccessibilityAction<T : Function<Unit>>(val label: String?, val action: T) {
    // TODO(b/145951226): Workaround for a bytecode issue, remove this
    override fun hashCode(): Int {
        var result = label?.hashCode() ?: 0
        // (action as Any) is the workaround
        result = 31 * result + (action as Any).hashCode()
        return result
    }
}

data class AccessibilityRangeInfo(
    val current: Float,
    val range: ClosedFloatingPointRange<Float>
)

interface SemanticsPropertyReceiver {
    operator fun <T> set(key: SemanticsPropertyKey<T>, value: T)
}
