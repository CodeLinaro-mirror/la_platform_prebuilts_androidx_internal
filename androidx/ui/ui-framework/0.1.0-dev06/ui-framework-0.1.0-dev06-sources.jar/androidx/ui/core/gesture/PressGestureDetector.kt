/*
 * Copyright 2019 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.ui.core.gesture

import androidx.compose.Composable
import androidx.ui.unit.PxPosition

@Composable
fun PressGestureDetector(
    onPress: ((PxPosition) -> Unit)? = null,
    onRelease: (() -> Unit)? = null,
    onCancel: (() -> Unit)? = null,
    enabled: Boolean = true,
    children: @Composable() () -> Unit
) {
    PressIndicatorGestureDetector(onStart = onPress, onCancel = onCancel, enabled = enabled) {
        PressReleasedGestureDetector(
            onRelease = onRelease,
            consumeDownOnStart = false,
            enabled = enabled,
            children = children
        )
    }
}