package androidx.test.espresso.device;

import androidx.test.platform.device.DeviceController;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.Generated;
import javax.inject.Provider;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class DeviceInteraction_Factory implements Factory<DeviceInteraction> {
  private final Provider<DeviceController> deviceControllerProvider;

  public DeviceInteraction_Factory(Provider<DeviceController> deviceControllerProvider) {
    this.deviceControllerProvider = deviceControllerProvider;
  }

  @Override
  public DeviceInteraction get() {
    return newInstance(deviceControllerProvider.get());
  }

  public static DeviceInteraction_Factory create(
      Provider<DeviceController> deviceControllerProvider) {
    return new DeviceInteraction_Factory(deviceControllerProvider);
  }

  public static DeviceInteraction newInstance(DeviceController deviceController) {
    return new DeviceInteraction(deviceController);
  }
}
