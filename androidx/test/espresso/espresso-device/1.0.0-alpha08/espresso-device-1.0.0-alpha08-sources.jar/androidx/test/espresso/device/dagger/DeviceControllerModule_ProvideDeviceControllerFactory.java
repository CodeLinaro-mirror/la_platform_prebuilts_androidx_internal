package androidx.test.espresso.device.dagger;

import androidx.test.platform.device.DeviceController;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class DeviceControllerModule_ProvideDeviceControllerFactory implements Factory<DeviceController> {
  private final DeviceControllerModule module;

  public DeviceControllerModule_ProvideDeviceControllerFactory(DeviceControllerModule module) {
    this.module = module;
  }

  @Override
  public DeviceController get() {
    return provideDeviceController(module);
  }

  public static DeviceControllerModule_ProvideDeviceControllerFactory create(
      DeviceControllerModule module) {
    return new DeviceControllerModule_ProvideDeviceControllerFactory(module);
  }

  public static DeviceController provideDeviceController(DeviceControllerModule instance) {
    return Preconditions.checkNotNullFromProvides(instance.provideDeviceController());
  }
}
