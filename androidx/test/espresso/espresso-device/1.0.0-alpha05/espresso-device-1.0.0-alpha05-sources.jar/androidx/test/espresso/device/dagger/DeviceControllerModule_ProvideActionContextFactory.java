package androidx.test.espresso.device.dagger;

import androidx.test.espresso.device.context.ActionContext;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class DeviceControllerModule_ProvideActionContextFactory implements Factory<ActionContext> {
  private final DeviceControllerModule module;

  public DeviceControllerModule_ProvideActionContextFactory(DeviceControllerModule module) {
    this.module = module;
  }

  @Override
  public ActionContext get() {
    return provideActionContext(module);
  }

  public static DeviceControllerModule_ProvideActionContextFactory create(
      DeviceControllerModule module) {
    return new DeviceControllerModule_ProvideActionContextFactory(module);
  }

  public static ActionContext provideActionContext(DeviceControllerModule instance) {
    return Preconditions.checkNotNullFromProvides(instance.provideActionContext());
  }
}
