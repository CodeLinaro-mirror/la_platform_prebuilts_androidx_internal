package androidx.test.espresso.device;

import androidx.test.espresso.device.context.ActionContext;
import androidx.test.platform.device.DeviceController;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.Generated;
import javax.inject.Provider;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class DeviceInteraction_Factory implements Factory<DeviceInteraction> {
  private final Provider<ActionContext> contextProvider;

  private final Provider<DeviceController> deviceControllerProvider;

  public DeviceInteraction_Factory(Provider<ActionContext> contextProvider,
      Provider<DeviceController> deviceControllerProvider) {
    this.contextProvider = contextProvider;
    this.deviceControllerProvider = deviceControllerProvider;
  }

  @Override
  public DeviceInteraction get() {
    return newInstance(contextProvider.get(), deviceControllerProvider.get());
  }

  public static DeviceInteraction_Factory create(Provider<ActionContext> contextProvider,
      Provider<DeviceController> deviceControllerProvider) {
    return new DeviceInteraction_Factory(contextProvider, deviceControllerProvider);
  }

  public static DeviceInteraction newInstance(ActionContext context,
      DeviceController deviceController) {
    return new DeviceInteraction(context, deviceController);
  }
}
