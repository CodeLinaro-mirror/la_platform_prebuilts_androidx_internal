package androidx.test.espresso.device.dagger;

import androidx.test.espresso.device.context.ActionContext;
import androidx.test.platform.device.DeviceController;
import dagger.internal.DaggerGenerated;
import dagger.internal.DoubleCheck;
import dagger.internal.Preconditions;
import javax.annotation.Generated;
import javax.inject.Provider;

@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class DaggerDeviceLayerComponent {
  private DaggerDeviceLayerComponent() {
  }

  public static Builder builder() {
    return new Builder();
  }

  public static DeviceLayerComponent create() {
    return new Builder().build();
  }

  public static final class Builder {
    private DeviceControllerModule deviceControllerModule;

    private Builder() {
    }

    public Builder deviceControllerModule(DeviceControllerModule deviceControllerModule) {
      this.deviceControllerModule = Preconditions.checkNotNull(deviceControllerModule);
      return this;
    }

    public DeviceLayerComponent build() {
      if (deviceControllerModule == null) {
        this.deviceControllerModule = new DeviceControllerModule();
      }
      return new DeviceLayerComponentImpl(deviceControllerModule);
    }
  }

  private static final class DeviceLayerComponentImpl implements DeviceLayerComponent {
    private final DeviceLayerComponentImpl deviceLayerComponentImpl = this;

    private Provider<ActionContext> provideActionContextProvider;

    private Provider<DeviceController> provideDeviceControllerProvider;

    private DeviceLayerComponentImpl(DeviceControllerModule deviceControllerModuleParam) {

      initialize(deviceControllerModuleParam);

    }

    @SuppressWarnings("unchecked")
    private void initialize(final DeviceControllerModule deviceControllerModuleParam) {
      this.provideActionContextProvider = DoubleCheck.provider(DeviceControllerModule_ProvideActionContextFactory.create(deviceControllerModuleParam));
      this.provideDeviceControllerProvider = DoubleCheck.provider(DeviceControllerModule_ProvideDeviceControllerFactory.create(deviceControllerModuleParam));
    }

    @Override
    public ActionContext actionContext() {
      return provideActionContextProvider.get();
    }

    @Override
    public DeviceController deviceController() {
      return provideDeviceControllerProvider.get();
    }
  }
}
