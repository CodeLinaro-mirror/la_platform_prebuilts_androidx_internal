/*
 * Copyright 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.core.animation;

import androidx.annotation.FloatRange;

/**
 * An interpolator where the change bounces at the end.
 */
public class BounceInterpolator implements Interpolator {

    /**
     * Creates a new instance of {@link BounceInterpolator}.
     */
    public BounceInterpolator() {
    }

    private static float bounce(float t) {
        return t * t * 8.0f;
    }

    @Override
    @FloatRange(from = 0, to = 1)
    public float getInterpolation(@FloatRange(from = 0, to = 1) float input) {
        // _b(t) = t * t * 8
        // bs(t) = _b(t) for t < 0.3535
        // bs(t) = _b(t - 0.54719) + 0.7 for t < 0.7408
        // bs(t) = _b(t - 0.8526) + 0.9 for t < 0.9644
        // bs(t) = _b(t - 1.0435) + 0.95 for t <= 1.0
        // b(t) = bs(t * 1.1226)
        float t = 1.1226f * input;
        if (t < 0.3535f) {
            return bounce(t);
        } else if (t < 0.7408f) {
            return bounce(t - 0.54719f) + 0.7f;
        } else if (t < 0.9644f) {
            return bounce(t - 0.8526f) + 0.9f;
        } else {
            return bounce(t - 1.0435f) + 0.95f;
        }
    }
}
