/*
 * Copyright 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.camera.camera2.internal.compat.quirk

import android.os.Build

public object Device {
    /**
     * There is no clear way to determine whether a device is UniSoc or not. Check the possible
     * properties to turn the results.
     */
    @JvmStatic
    public fun isUniSocChipsetDevice(): Boolean {
        return (Build.VERSION.SDK_INT >= 31 &&
            "Spreadtrum".equals(Build.SOC_MANUFACTURER, ignoreCase = true)) ||
            Build.HARDWARE.lowercase().startsWith("ums") ||
            (isItelDevice() && Build.HARDWARE.lowercase().startsWith("sp"))
    }

    private fun isItelDevice(): Boolean = isDeviceFrom("Itel")

    private fun isDeviceFrom(vendor: String) =
        Build.MANUFACTURER.equalsCaseInsensitive(vendor) ||
            Build.BRAND.equalsCaseInsensitive(vendor)

    private fun String.equalsCaseInsensitive(other: String?) = equals(other, ignoreCase = true)
}
