/*
 * Copyright 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.camera.view.internal;

import androidx.camera.core.ImageCapture;
import androidx.camera.view.CameraController;
import androidx.camera.view.PreviewView;
import androidx.camera.view.ScreenFlashView;

import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

import java.util.Objects;

/**
 * Internal data class that encapsulates an {@link ImageCapture.ScreenFlash} and its
 * provider.
 */
public class ScreenFlashUiInfo {
    /**
     * Since {@link ImageCapture.ScreenFlash} can be created from either the
     * {@link ScreenFlashView} set by user or the one internally used in {@link PreviewView},
     * {@link CameraController} needs to know where exactly the control is from so that it can
     * prioritize the user-set one when both are available.
     */
    public enum ProviderType {
        PREVIEW_VIEW,
        SCREEN_FLASH_VIEW
    }

    private final @NonNull ProviderType mProviderType;

    private final ImageCapture.@Nullable ScreenFlash mScreenFlash;

    public ScreenFlashUiInfo(@NonNull ProviderType providerType,
            ImageCapture.@Nullable ScreenFlash screenFlash) {
        mProviderType = providerType;
        mScreenFlash = screenFlash;
    }

    public @NonNull ProviderType getProviderType() {
        return mProviderType;
    }

    public ImageCapture.@Nullable ScreenFlash getScreenFlash() {
        return mScreenFlash;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ScreenFlashUiInfo)) return false;
        ScreenFlashUiInfo that = (ScreenFlashUiInfo) o;
        return mProviderType == that.mProviderType && Objects.equals(mScreenFlash,
                that.mScreenFlash);
    }

    @Override
    public int hashCode() {
        return Objects.hash(mProviderType, mScreenFlash);
    }
}
