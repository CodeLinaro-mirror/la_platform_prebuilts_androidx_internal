/*
 * Copyright 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.xr.scenecore.spatial.core;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Rect;
import android.os.Bundle;

import androidx.xr.scenecore.runtime.ActivityPanelEntity;
import androidx.xr.scenecore.runtime.PixelDimensions;

import com.android.extensions.xr.XrExtensions;
import com.android.extensions.xr.node.Node;
import com.android.extensions.xr.node.NodeTransaction;
import com.android.extensions.xr.space.ActivityPanel;

import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

import java.util.Objects;
import java.util.concurrent.ScheduledExecutorService;

/** Implementation of {@link ActivityPanelEntity}. */
class ActivityPanelEntityImpl extends BasePanelEntity implements ActivityPanelEntity {
    private final ActivityPanel mActivityPanel;

    // TODO(b/352630140): Add a static factory method and remove the business logic from
    //                    SpatialSceneRuntime.

    ActivityPanelEntityImpl(
            Context context,
            Node node,
            String name,
            XrExtensions extensions,
            EntityManager entityManager,
            ActivityPanel activityPanel,
            PixelDimensions windowBoundsPx,
            ScheduledExecutorService executor) {
        super(context, node, extensions, entityManager, executor);
        // We need to notify our base class of the pixelDimensions, even though the Extensions are
        // initialized in the factory method. (ext.ActivityPanel.setWindowBounds, etc)
        super.setSizeInPixels(windowBoundsPx);
        float cornerRadius = getDefaultCornerRadiusInMeters();
        try (NodeTransaction transaction = mExtensions.createNodeTransaction()) {
            transaction
                    .setVisibility(activityPanel.getNode(), true)
                    .setName(activityPanel.getNode(), name)
                    .setCornerRadius(activityPanel.getNode(), cornerRadius)
                    .apply();
        }
        mActivityPanel = activityPanel;
        super.setCornerRadiusValue(cornerRadius);
    }

    @Override
    public void launchActivity(@NonNull Intent intent, @Nullable Bundle bundle) {
        // Note that launching an Activity into the Panel doesn't actually update the size. The
        // application is expected to set the size of the ActivityPanel at construction time, before
        // launching an Activity into it. The Activity will then render into the size the
        // application specified, and the system will apply letterboxing if necessary.
        mActivityPanel.launchActivity(intent, bundle);
    }

    @Override
    public void moveActivity(@NonNull Activity activity) {
        // Note that moving an Activity into the Panel doesn't actually update the size. The
        // application should explicitly call setPixelDimensions() to update the size of an
        // ActivityPanel.
        mActivityPanel.moveActivity(activity);
    }

    @Override
    public void setSizeInPixels(@NonNull PixelDimensions dimensions) {
        PixelDimensions oldDimensions = mPixelDimensions;
        super.setSizeInPixels(dimensions);

        // Avoid updating the bounds if we were called with the same values.
        if (Objects.equals(oldDimensions, dimensions)) {
            return;
        }

        mActivityPanel.setWindowBounds(new Rect(0, 0, dimensions.width, dimensions.height));
    }

    /**
     * Disposes the ActivityPanelEntity.
     *
     * <p>This will delete the ActivityPanel and destroy the embedded activity.
     */
    @Override
    public void dispose() {
        mActivityPanel.delete();
        super.dispose();
    }
}
