/*
 * Copyright 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.xr.scenecore

import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.xr.runtime.math.FloatSize2d
import androidx.xr.runtime.math.FloatSize3d
import androidx.xr.runtime.math.IntSize2d
import androidx.xr.runtime.math.Ray
import androidx.xr.scenecore.HitTestResult.SurfaceType
import androidx.xr.scenecore.InputEvent.HitInfo
import androidx.xr.scenecore.ScenePose.HitTestFilter
import androidx.xr.scenecore.runtime.ActivityPose.HitTestFilter as RtHitTestFilter
import androidx.xr.scenecore.runtime.AnchorEntity as RtAnchorEntity
import androidx.xr.scenecore.runtime.AnchorPlacement as RtAnchorPlacement
import androidx.xr.scenecore.runtime.Dimensions as RtDimensions
import androidx.xr.scenecore.runtime.HitTestResult as RtHitTestResult
import androidx.xr.scenecore.runtime.HitTestResult.HitTestSurfaceType as RtHitTestSurfaceType
import androidx.xr.scenecore.runtime.InputEvent as RtInputEvent
import androidx.xr.scenecore.runtime.InputEvent.HitInfo as RtHitInfo
import androidx.xr.scenecore.runtime.KhronosPbrMaterialSpec as RtKhronosPbrMaterialSpec
import androidx.xr.scenecore.runtime.MoveEvent as RtMoveEvent
import androidx.xr.scenecore.runtime.PerceivedResolutionResult as RtPerceivedResolutionResult
import androidx.xr.scenecore.runtime.PixelDimensions as RtPixelDimensions
import androidx.xr.scenecore.runtime.PlaneSemantic as RtPlaneSemantic
import androidx.xr.scenecore.runtime.PlaneType as RtPlaneType
import androidx.xr.scenecore.runtime.ResizeEvent as RtResizeEvent
import androidx.xr.scenecore.runtime.SceneRuntime
import androidx.xr.scenecore.runtime.Space as RtSpace
import androidx.xr.scenecore.runtime.SpatialCapabilities as RtSpatialCapabilities
import androidx.xr.scenecore.runtime.SpatialPointerIcon as RtSpatialPointerIcon
import androidx.xr.scenecore.runtime.SpatialPointerIconType as RtSpatialPointerIconType
import androidx.xr.scenecore.runtime.SpatialVisibility as RtSpatialVisibility
import androidx.xr.scenecore.runtime.TextureSampler as RtTextureSampler
import com.google.common.util.concurrent.ListenableFuture
import java.util.concurrent.Executor
import kotlin.coroutines.coroutineContext
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Job

internal class HandlerExecutor(val handler: Handler) : Executor {
    override fun execute(command: Runnable) {
        handler.post(command)
    }

    companion object {
        val mainThreadExecutor: Executor = HandlerExecutor(Handler(Looper.getMainLooper()))
    }
}

/**
 * Extension function that converts a [androidx.xr.runtime.math.FloatSize3d] to
 * [androidx.xr.scenecore.runtime.Dimensions].
 */
internal fun FloatSize3d.toRtDimensions(): RtDimensions {
    return RtDimensions(width, height, depth)
}

/**
 * Extension function that converts a [androidx.xr.runtime.math.FloatSize2d] to
 * [androidx.xr.scenecore.runtime.Dimensions], setting the `depth` field to 0.
 */
internal fun FloatSize2d.toRtDimensions(): RtDimensions {
    return RtDimensions(width, height, 0f)
}

/**
 * Extension function that converts a [androidx.xr.scenecore.runtime.Dimensions] to [FloatSize3d].
 */
internal fun RtDimensions.toFloatSize3d(): FloatSize3d {
    return FloatSize3d(width, height, depth)
}

/**
 * Extension function that converts a [androidx.xr.scenecore.runtime.Dimensions] to [FloatSize3d].
 */
internal fun RtDimensions.toFloatSize2d(): FloatSize2d {
    return FloatSize2d(width, height)
}

/**
 * Extension function that converts a [androidx.xr.runtime.math.IntSize2d] to
 * [androidx.xr.scenecore.runtime.PixelDimensions].
 */
internal fun IntSize2d.toRtPixelDimensions(): RtPixelDimensions {
    return RtPixelDimensions(width, height)
}

/**
 * Extension function that converts a [androidx.xr.scenecore.runtime.PixelDimensions] to
 * [IntSize2d].
 */
internal fun RtPixelDimensions.toIntSize2d(): IntSize2d {
    return IntSize2d(width, height)
}

/**
 * Extension function that converts [Int] to
 * [androidx.xr.scenecore.runtime.SceneRuntime.planeOrientation].
 */
internal fun Int.toRtPlaneType(): RtPlaneType {
    return when (this) {
        PlaneOrientation.HORIZONTAL -> RtPlaneType.HORIZONTAL
        PlaneOrientation.VERTICAL -> RtPlaneType.VERTICAL
        PlaneOrientation.ANY -> RtPlaneType.ANY
        else -> error("Unknown Plane Type: $PlaneOrientation")
    }
}

/**
 * Extension function that converts [Int] to
 * [androidx.xr.scenecore.runtime.SceneRuntime.PlaneSemantic].
 */
internal fun Int.toRtPlaneSemantic(): RtPlaneSemantic {
    return when (this) {
        PlaneSemanticType.WALL -> RtPlaneSemantic.WALL
        PlaneSemanticType.FLOOR -> RtPlaneSemantic.FLOOR
        PlaneSemanticType.CEILING -> RtPlaneSemantic.CEILING
        PlaneSemanticType.TABLE -> RtPlaneSemantic.TABLE
        PlaneSemanticType.ANY -> RtPlaneSemantic.ANY
        else -> error("Unknown Plane Semantic: $PlaneSemanticType")
    }
}

/**
 * Extension function that converts [Space] value to
 * [androidx.xr.scenecore.runtime.SceneRuntime.Space] value.
 */
internal fun Int.toRtSpace(): Int {
    return when (this) {
        Space.PARENT -> RtSpace.PARENT
        Space.ACTIVITY -> RtSpace.ACTIVITY
        Space.REAL_WORLD -> RtSpace.REAL_WORLD
        else -> error("Unknown Space Value: $this")
    }
}

/**
 * Extension function that converts a [androidx.xr.scenecore.runtime.MoveEvent] to a [MoveEvent].
 */
internal fun RtMoveEvent.toMoveEvent(entityManager: EntityManager): MoveEvent {

    disposedEntity?.let { entityManager.removeEntity(it) }
    return MoveEvent(
        moveState.toMoveState(),
        Ray(initialInputRay.origin, initialInputRay.direction),
        Ray(currentInputRay.origin, currentInputRay.direction),
        previousPose,
        currentPose,
        previousScale.x,
        currentScale.x,
        entityManager.getEntityForRtEntity(initialParent)!!,
        updatedParent?.let {
            entityManager.getEntityForRtEntity(it)
                ?: AnchorEntity.create(it as RtAnchorEntity, entityManager)
        },
    )
}

/** Extension function that converts a [RtHitInfo] to a [HitInfo]. */
internal fun RtHitInfo.toHitInfo(entityManager: EntityManager): HitInfo? {
    // TODO: b/377541143 - Replace instance equality check in EntityManager.
    val hitEntity = entityManager.getEntityForRtEntity(inputEntity)
    return if (hitEntity == null) {
        null
    } else {
        HitInfo(inputEntity = hitEntity, hitPosition = hitPosition, transform = transform)
    }
}

/**
 * Extension function that converts a [androidx.xr.scenecore.runtime.InputEvent] to a [InputEvent].
 */
internal fun RtInputEvent.toInputEvent(entityManager: EntityManager): InputEvent {
    val hitInfos = mutableListOf<HitInfo>()
    hitInfoList.forEach { it.toHitInfo(entityManager)?.let { element -> hitInfos.add(element) } }
    return InputEvent(
        source.toInputEventSource(),
        pointerType.toInputEventPointerType(),
        timestamp,
        origin,
        direction,
        action.toInputEventAction(),
        hitInfos,
    )
}

/**
 * Extension function that converts a [androidx.xr.scenecore.runtime.SpatialCapabilities] to a
 * [SpatialCapabilities].
 */
internal fun RtSpatialCapabilities.toSpatialCapabilities(): SpatialCapabilities {
    return SpatialCapabilities(capabilities.toSpatialCapability())
}

/**
 * Extension function that converts a [androidx.xr.scenecore.runtime.SpatialVisibility] to a
 * [SpatialVisibilityValue].
 */
@SpatialVisibilityValue
internal fun RtSpatialVisibility.toSpatialVisibility(): Int {
    return visibility.toSpatialVisibilityValue()
}

/**
 * Extension function that converts a [androidx.xr.scenecore.runtime.ResizeEvent] to a
 * [ResizeEvent].
 */
internal fun RtResizeEvent.toResizeEvent(entity: Entity): ResizeEvent {
    return ResizeEvent(entity, resizeState.toResizeState(), newSize.toFloatSize3d())
}

/**
 * Extension function that converts a [Set] of [AnchorPlacement] to a [Set] of
 * [androidx.xr.scenecore.runtime.SceneRuntime.AnchorPlacement].
 */
internal fun Set<AnchorPlacement>.toRtAnchorPlacement(
    sceneRuntime: SceneRuntime
): Set<RtAnchorPlacement> {
    val rtAnchorPlacementSet = HashSet<RtAnchorPlacement>()
    for (placement in this) {
        val planeOrientationFilter =
            placement.anchorablePlaneOrientations.map { it.toRtPlaneType() }.toMutableSet()
        val planeSemanticFilter =
            placement.anchorablePlaneSemanticTypes.map { it.toRtPlaneSemantic() }.toMutableSet()

        val rtAnchorPlacement =
            sceneRuntime.createAnchorPlacementForPlanes(planeOrientationFilter, planeSemanticFilter)
        rtAnchorPlacementSet.add(rtAnchorPlacement)
    }
    return rtAnchorPlacementSet
}

/** Extension function that converts a [Int] to [MoveEvent.MoveState]. */
@MoveEvent.MoveState
internal fun Int.toMoveState(): Int {
    return when (this) {
        RtMoveEvent.MOVE_STATE_START -> MoveEvent.MOVE_STATE_START
        RtMoveEvent.MOVE_STATE_ONGOING -> MoveEvent.MOVE_STATE_ONGOING
        RtMoveEvent.MOVE_STATE_END -> MoveEvent.MOVE_STATE_END
        else -> error("Unknown Move State: $this")
    }
}

/** Extension function that converts a [Int] to [ResizeEvent.ResizeState]. */
@ResizeEvent.ResizeStateValue
internal fun Int.toResizeState(): Int {
    return when (this) {
        RtResizeEvent.RESIZE_STATE_UNKNOWN -> ResizeEvent.ResizeState.RESIZE_STATE_UNKNOWN
        RtResizeEvent.RESIZE_STATE_START -> ResizeEvent.ResizeState.RESIZE_STATE_START
        RtResizeEvent.RESIZE_STATE_ONGOING -> ResizeEvent.ResizeState.RESIZE_STATE_ONGOING
        RtResizeEvent.RESIZE_STATE_END -> ResizeEvent.ResizeState.RESIZE_STATE_END
        else -> error("Unknown Resize State: $this")
    }
}

/** Extension function that converts a [Int] to [InputEvent.SourceValue]. */
@InputEvent.SourceValue
internal fun Int.toInputEventSource(): Int {
    return when (this) {
        RtInputEvent.Source.UNKNOWN -> InputEvent.Source.SOURCE_UNKNOWN
        RtInputEvent.Source.HEAD -> InputEvent.Source.SOURCE_HEAD
        RtInputEvent.Source.CONTROLLER -> InputEvent.Source.SOURCE_CONTROLLER
        RtInputEvent.Source.HANDS -> InputEvent.Source.SOURCE_HANDS
        RtInputEvent.Source.MOUSE -> InputEvent.Source.SOURCE_MOUSE
        RtInputEvent.Source.GAZE_AND_GESTURE -> InputEvent.Source.SOURCE_GAZE_AND_GESTURE
        else -> error("Unknown Input Event Source: $this")
    }
}

/** Extension function that converts a [Int] to [InputEvent.Pointer]. */
@InputEvent.PointerType
internal fun Int.toInputEventPointerType(): Int {
    return when (this) {
        RtInputEvent.Pointer.DEFAULT -> InputEvent.Pointer.POINTER_TYPE_DEFAULT
        RtInputEvent.Pointer.LEFT -> InputEvent.Pointer.POINTER_TYPE_LEFT
        RtInputEvent.Pointer.RIGHT -> InputEvent.Pointer.POINTER_TYPE_RIGHT
        else -> error("Unknown Input Event Pointer Type: $this")
    }
}

/** Extension function that converts a [Int] to [SpatialCapability]. */
@SpatialCapability
internal fun Int.toSpatialCapability(): Int {
    return this
}

/** Extension function that converts a [Int] to [SpatialVisibilityValue]. */
@SpatialVisibilityValue
internal fun Int.toSpatialVisibilityValue(): Int {
    return when (this) {
        RtSpatialVisibility.UNKNOWN -> SpatialVisibility.SPATIAL_VISIBILITY_UNKNOWN
        RtSpatialVisibility.OUTSIDE_FOV ->
            SpatialVisibility.SPATIAL_VISIBILITY_OUTSIDE_FIELD_OF_VIEW
        RtSpatialVisibility.PARTIALLY_WITHIN_FOV ->
            SpatialVisibility.SPATIAL_VISIBILITY_PARTIALLY_WITHIN_FIELD_OF_VIEW
        RtSpatialVisibility.WITHIN_FOV -> SpatialVisibility.SPATIAL_VISIBILITY_WITHIN_FIELD_OF_VIEW
        else -> error("Unknown Spatial Visibility Value: $this")
    }
}

/** Extension function that converts a [Int] to [InputEvent.ActionValue]. */
@InputEvent.ActionValue
internal fun Int.toInputEventAction(): Int {
    return when (this) {
        RtInputEvent.Action.DOWN -> InputEvent.Action.ACTION_DOWN
        RtInputEvent.Action.UP -> InputEvent.Action.ACTION_UP
        RtInputEvent.Action.MOVE -> InputEvent.Action.ACTION_MOVE
        RtInputEvent.Action.CANCEL -> InputEvent.Action.ACTION_CANCEL
        RtInputEvent.Action.HOVER_MOVE -> InputEvent.Action.ACTION_HOVER_MOVE
        RtInputEvent.Action.HOVER_ENTER -> InputEvent.Action.ACTION_HOVER_ENTER
        RtInputEvent.Action.HOVER_EXIT -> InputEvent.Action.ACTION_HOVER_EXIT
        else -> error("Unknown Input Event Action: $this")
    }
}

/**
 * Extension function that converts a [TextureSampler] to
 * [androidx.xr.scenecore.runtime.TextureSampler].
 */
internal fun TextureSampler.toRtTextureSampler(): RtTextureSampler {
    return RtTextureSampler(
        wrapModeHorizontal,
        wrapModeVertical,
        wrapModeDepth,
        minificationFilter,
        magnificationFilter,
        compareMode,
        compareFunction,
        anisotropyLog2,
    )
}

/** Extension function that converts a [HitTestFilter] to a [RtHitTestFilter]. */
internal fun Int.toRtHitTestFilter(): Int {
    var filters: Int = 0
    if (this and HitTestFilter.OTHER_SCENES != 0) {
        filters = filters or RtHitTestFilter.OTHER_SCENES
    }
    if (this and HitTestFilter.SELF_SCENE != 0) {
        filters = filters or RtHitTestFilter.SELF_SCENE
    }
    return filters
}

/** Extension function that converts a [RtHitTestSurfaceType] to a [HitTestResult.SurfaceType]. */
internal fun Int.toHitTestSurfaceType(): Int {
    return when (this) {
        RtHitTestSurfaceType.HIT_TEST_RESULT_SURFACE_TYPE_UNKNOWN -> SurfaceType.UNKNOWN
        RtHitTestSurfaceType.HIT_TEST_RESULT_SURFACE_TYPE_PLANE -> SurfaceType.PLANE
        RtHitTestSurfaceType.HIT_TEST_RESULT_SURFACE_TYPE_OBJECT -> SurfaceType.OBJECT
        else -> SurfaceType.UNKNOWN
    }
}

/**
 * Extension function that converts a [androidx.xr.scenecore.runtime.HitTestResult] to a
 * [HitTestResult].
 */
internal fun RtHitTestResult.toHitTestResult(): HitTestResult {
    return HitTestResult(hitPosition, surfaceNormal, surfaceType.toHitTestSurfaceType(), distance)
}

@RtSpatialPointerIconType
internal fun SpatialPointerIcon.toRtSpatialPointerIcon(): Int {
    return when (this) {
        SpatialPointerIcon.NONE -> RtSpatialPointerIcon.TYPE_NONE
        SpatialPointerIcon.CIRCLE -> RtSpatialPointerIcon.TYPE_CIRCLE
        SpatialPointerIcon.DEFAULT -> RtSpatialPointerIcon.TYPE_DEFAULT
        else -> error("Unknown spatial pointer icon type: $this")
    }
}

internal fun Int.toSpatialPointerIcon(): SpatialPointerIcon {
    return when (this) {
        RtSpatialPointerIcon.TYPE_NONE -> SpatialPointerIcon.NONE
        RtSpatialPointerIcon.TYPE_CIRCLE -> SpatialPointerIcon.CIRCLE
        RtSpatialPointerIcon.TYPE_DEFAULT -> SpatialPointerIcon.DEFAULT
        else -> error("Unknown spatial pointer icon type: $this")
    }
}

/**
 * Extension function that converts a [AlphaMode] to
 * [androidx.xr.scenecore.runtime.KhronosPbrMaterialSpec].
 */
internal fun Int.toRtKhronosUnlitMaterialSpec(): RtKhronosPbrMaterialSpec {
    return RtKhronosPbrMaterialSpec(
        lightingModel = RtKhronosPbrMaterialSpec.UNLIT,
        blendMode = this,
        doubleSidedMode = RtKhronosPbrMaterialSpec.SINGLE_SIDED,
    )
}

/**
 * Extension function that converts a [AlphaMode] to
 * [androidx.xr.scenecore.runtime.KhronosPbrMaterialSpec].
 */
internal fun Int.toRtKhronosPbrMaterialSpec(): RtKhronosPbrMaterialSpec {
    return RtKhronosPbrMaterialSpec(
        lightingModel = RtKhronosPbrMaterialSpec.LIT,
        blendMode = this,
        doubleSidedMode = RtKhronosPbrMaterialSpec.SINGLE_SIDED,
    )
}

/**
 * Extension function that converts a [androidx.xr.scenecore.runtime.PerceivedResolutionResult] to
 * [PerceivedResolutionResult].
 */
internal fun RtPerceivedResolutionResult.toPerceivedResolutionResult(): PerceivedResolutionResult {
    return when (this) {
        is RtPerceivedResolutionResult.Success ->
            PerceivedResolutionResult.Success(this.perceivedResolution.toIntSize2d())
        is RtPerceivedResolutionResult.EntityTooClose -> PerceivedResolutionResult.EntityTooClose()
        is RtPerceivedResolutionResult.InvalidCameraView ->
            PerceivedResolutionResult.InvalidCameraView()
    }
}

internal suspend fun <T> ListenableFuture<T>.awaitSuspending(): T {
    val deferred = CompletableDeferred<T>(coroutineContext[Job])
    val futureBeingAwaited = this

    this.addListener(
        Runnable {
            try {
                deferred.complete(this.get())
            } catch (e: Throwable) {
                Log.e("AwaitSuspending", "ListenableFuture failed: $futureBeingAwaited", e)
                deferred.completeExceptionally(e)
            }
        },
        DirectExecutor,
    )

    return deferred.await()
}

internal object DirectExecutor : Executor {
    override fun execute(command: Runnable) {
        command.run()
    }
}
