/*
 * Copyright 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.xr.runtime.testing

import androidx.xr.runtime.internal.Anchor

/** Object that holds [Anchor] instances. */
internal interface AnchorHolder {

    /** Notifies the [AnchorHolder] that the given [Anchor] has been persisted. */
    public fun onAnchorPersisted(anchor: Anchor)

    /**
     * Detaches the given [Anchor] from this trackable. Single [Anchor] instances rely on this
     * function to remove themselves from the [AnchorHolder].
     */
    public fun detachAnchor(anchor: Anchor)
}
