/*
 * Copyright 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.xr.runtime

import androidx.annotation.RestrictTo

/**
 * Defines a configuration state of all available features to be set at runtime.
 *
 * An instance of this class should be passed to [Session.configure()] to modify the current
 * configuration.
 */
public class Config
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP_PREFIX)
constructor(
    public val planeTracking: PlaneTrackingMode = PlaneTrackingMode.Disabled,
    public val handTracking: HandTrackingMode = HandTrackingMode.Disabled,
    public val depthEstimation: DepthEstimationMode = DepthEstimationMode.Disabled,
    public val anchorPersistence: AnchorPersistenceMode = AnchorPersistenceMode.Disabled,
    public val headTracking: HeadTrackingMode = HeadTrackingMode.Disabled,
    @get:RestrictTo(RestrictTo.Scope.LIBRARY_GROUP_PREFIX)
    public val geospatial: GeospatialMode = GeospatialMode.Disabled,
) {

    public constructor(
        planeTracking: PlaneTrackingMode = PlaneTrackingMode.Disabled,
        handTracking: HandTrackingMode = HandTrackingMode.Disabled,
        depthEstimation: DepthEstimationMode = DepthEstimationMode.Disabled,
        anchorPersistence: AnchorPersistenceMode = AnchorPersistenceMode.Disabled,
        headTracking: HeadTrackingMode = HeadTrackingMode.Disabled,
    ) : this(
        planeTracking,
        handTracking,
        depthEstimation,
        anchorPersistence,
        headTracking,
        GeospatialMode.Disabled
    )

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is Config) return false

        if (planeTracking != other.planeTracking) return false
        if (handTracking != other.handTracking) return false
        if (depthEstimation != other.depthEstimation) return false
        if (anchorPersistence != other.anchorPersistence) return false
        if (headTracking != other.headTracking) return false
        if (geospatial != other.geospatial) return false

        return true
    }

    override fun hashCode(): Int {
        var result = planeTracking.hashCode()
        result = 31 * result + handTracking.hashCode()
        result = 31 * result + depthEstimation.hashCode()
        result = 31 * result + anchorPersistence.hashCode()
        result = 31 * result + headTracking.hashCode()
        result = 31 * result + geospatial.hashCode()
        return result
    }

    @JvmOverloads
    public fun copy(
        planeTracking: PlaneTrackingMode = this.planeTracking,
        handTracking: HandTrackingMode = this.handTracking,
        depthEstimation: DepthEstimationMode = this.depthEstimation,
        anchorPersistence: AnchorPersistenceMode = this.anchorPersistence,
        headTracking: HeadTrackingMode = this.headTracking,
    ): Config {
        return Config(
            planeTracking = planeTracking,
            handTracking = handTracking,
            depthEstimation = depthEstimation,
            anchorPersistence = anchorPersistence,
            headTracking = headTracking,
            geospatial = this.geospatial,
        )
    }

    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP_PREFIX)
    public fun copy(
        planeTracking: PlaneTrackingMode = this.planeTracking,
        handTracking: HandTrackingMode = this.handTracking,
        depthEstimation: DepthEstimationMode = this.depthEstimation,
        anchorPersistence: AnchorPersistenceMode = this.anchorPersistence,
        headTracking: HeadTrackingMode = this.headTracking,
        geospatial: GeospatialMode = this.geospatial,
    ): Config {
        return Config(
            planeTracking = planeTracking,
            handTracking = handTracking,
            depthEstimation = depthEstimation,
            anchorPersistence = anchorPersistence,
            headTracking = headTracking,
            geospatial = geospatial,
        )
    }

    /**
     * Feature that allows tracking of and provides information about scene planes.
     *
     * Setting this feature to [PlaneTrackingMode.HorizontalAndVertical] requires that the
     * `SCENE_UNDERSTANDING_COARSE` Android permission is granted.
     */
    public class PlaneTrackingMode
    private constructor(
        @get:RestrictTo(RestrictTo.Scope.LIBRARY_GROUP_PREFIX) public val mode: Int
    ) {
        public companion object {
            /** Planes will not be tracked. */
            @JvmField public val Disabled: PlaneTrackingMode = PlaneTrackingMode(0)
            /**
             * Horizontal and vertical planes will be tracked. Note that setting this mode will
             * consume additional runtime resources.
             */
            @JvmField public val HorizontalAndVertical: PlaneTrackingMode = PlaneTrackingMode(1)
        }

        override fun toString(): String {
            return "PlaneTracking_" + if (mode == 0) "Disabled" else "HorizontalAndVertical"
        }
    }

    /**
     * Feature that allows tracking of the user's hands and hand joints.
     *
     * Setting this feature to [HandTrackingMode.Enabled] requires that the `HAND_TRACKING` Android
     * permission is granted by the calling application.
     */
    public class HandTrackingMode
    private constructor(
        @get:RestrictTo(RestrictTo.Scope.LIBRARY_GROUP_PREFIX) public val mode: Int
    ) {
        public companion object {
            /** Hands will not be tracked. */
            @JvmField public val Disabled: HandTrackingMode = HandTrackingMode(0)
            /**
             * Hands will be tracked. Note that setting this mode will consume additional runtime
             * resources.
             */
            @JvmField public val Enabled: HandTrackingMode = HandTrackingMode(1)
        }

        override fun toString(): String {
            return "HandTracking_" + if (mode == 0) "Disabled" else "Enabled"
        }
    }

    /**
     * Feature that allows more accurate information about scene depth and meshes.
     *
     * Setting this feature to [DepthEstimationMode.Enabled] requires that the
     * `SCENE_UNDERSTANDING_FINE` Android permission is granted by the calling application.
     */
    public class DepthEstimationMode
    private constructor(
        @get:RestrictTo(RestrictTo.Scope.LIBRARY_GROUP_PREFIX) public val mode: Int
    ) {
        public companion object {
            /** No information about scene depth will be provided. */
            @JvmField public val Disabled: DepthEstimationMode = DepthEstimationMode(0)
            /**
             * Depth estimation will be enabled. Note that setting this mode will consume additional
             * runtime resources.
             */
            @JvmField public val Enabled: DepthEstimationMode = DepthEstimationMode(1)
        }

        override fun toString(): String {
            return "DepthEstimation_" + if (mode == 0) "Disabled" else "Enabled"
        }
    }

    /**
     * Feature that allows [Anchor]'s to be peristed through sessions.
     *
     * This feature does not require any additional application permissions.
     */
    public class AnchorPersistenceMode
    private constructor(
        @get:RestrictTo(RestrictTo.Scope.LIBRARY_GROUP_PREFIX) public val mode: Int
    ) {
        public companion object {
            /** Anchors cannot be persisted. */
            @JvmField public val Disabled: AnchorPersistenceMode = AnchorPersistenceMode(0)
            /** Anchors may be persisted. */
            @JvmField public val Enabled: AnchorPersistenceMode = AnchorPersistenceMode(1)
        }

        override fun toString(): String {
            return "AnchorPersistence_" + if (mode == 0) "Disabled" else "Enabled"
        }
    }

    /**
     * Feature that allows tracking of the user's head pose.
     *
     * Setting this feature to [HeadTracking.Enabled] requires that the `HEAD_TRACKING` Android
     * permission is granted by the calling application.
     */
    public class HeadTrackingMode
    private constructor(
        @get:RestrictTo(RestrictTo.Scope.LIBRARY_GROUP_PREFIX) public val mode: Int
    ) {
        public companion object {
            /** Head pose will not be tracked. */
            @JvmField public val Disabled: HeadTrackingMode = HeadTrackingMode(0)
            /** Head pose will be tracked. */
            @JvmField public val Enabled: HeadTrackingMode = HeadTrackingMode(1)
        }
    }

    /**
     * Feature that allows Geospatial localization and tracking. The Geospatial API uses a
     * combination of Google's Visual Positioning System (VPS) and GPS to determine the geospatial
     * pose.
     *
     * The Geospatial API is able to provide the best user experience when it is able to generate
     * high accuracy poses. However, the Geospatial API can be used anywhere, as long as the device
     * is able to determine its location, even if the available location information has low
     * accuracy.
     * - In areas with VPS coverage, the Geospatial API is able to generate high accuracy poses.
     *   This can work even where GPS accuracy is low, such as dense urban environments. Under
     *   typical conditions, VPS can be expected to provide positional accuracy typically better
     *   than 5 meters and often around 1 meter, and a rotational accuracy of better than 5 degrees.
     *   Use [Earth.checkVpsAvailability] to determine if a given location has VPS coverage.
     * - In outdoor environments with few or no overhead obstructions, GPS may be sufficient to
     *   generate high accuracy poses. GPS accuracy may be low in dense urban environments and
     *   indoors.
     *
     * Setting this feature to [GeospatialMode.Enabled] requires TODO: b/393500151 - permissions.
     *
     * Note that setting this mode will consume additional runtime resources.
     */
    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP_PREFIX)
    public class GeospatialMode
    private constructor(
        @get:RestrictTo(RestrictTo.Scope.LIBRARY_GROUP_PREFIX) public val mode: Int
    ) {
        public companion object {
            /**
             * The Geospatial API is disabled. When GeospatialMode is disabled, current [Anchor]
             * objects created from [Earth] will stop updating, and have their [TrackingState] set
             * to [TrackingState.Stopped].
             */
            @JvmField public val Disabled: GeospatialMode = GeospatialMode(0)

            /**
             * The Geospatial API is enabled. [Earth] should enter the running state shortly after
             * this mode is set.
             *
             * Using this mode requires your app do the following, depending on the Runtime:
             *
             * On Mobile:
             * - Include the
             *   [ACCESS_INTERNET](https://developer.android.com/training/basics/network-ops/connecting)
             *   permission to the app's AndroidManifest
             * - Include the Google Play Services Location Library as a dependency for your app. See
             *   [dependencies for Google Play services](https://developers.google.com/android/guides/setup#declare-dependencies)
             *   for instructions on how to include this library in your app. If this library is not
             *   linked, [session.configure] returns
             *   [SessionResultGooglePlayServicesLocationLibraryNotLinked]
             * - Request and be granted the
             *   [ACCESS_FINE_LOCATION permission](https://developer.android.com/training/location/permissions);
             *   otherwise, [Session.configure] returns [SessionConfigurePermissionNotGranted]
             *
             * Location is tracked only while the [Session] is resumed.
             *
             * For more information, see documentation on
             * [the Geospatial API on Google Developers](https://developers.google.com/ar/develop/java/geospatial/developer-guide).
             *
             * On Mobile, when the Geospatial API and the Depth API are enabled, output images from
             * the Depth API will include terrain and building geometry when in a location with VPS
             * coverage. See the
             * [Geospatial Depth Developer Guide](https://developers.google.com/ar/develop/java/depth/geospatial-depth)
             * for more information.
             *
             * On mobile, this mode is not compatible with the front-facing (selfie) camera. If
             * Config.GeospatialMode is Enabled on a session using the front-facing (selfie) camera,
             * [Session.configure] will return [SessionConfigureConfigurationNotSupported].
             *
             * Not all devices support GeospatialMode.Enabled, use [Earth.isGeospatialModeSupported]
             * to check if the current device and selected camera support enabling this mode. These
             * checks are done in the call to [Session.configure].
             */
            @JvmField public val Enabled: GeospatialMode = GeospatialMode(1)
        }
    }
}
