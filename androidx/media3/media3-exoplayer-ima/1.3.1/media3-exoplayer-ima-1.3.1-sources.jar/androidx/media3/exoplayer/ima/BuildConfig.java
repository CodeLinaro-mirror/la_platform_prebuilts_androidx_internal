/**
 * Automatically generated file. DO NOT MODIFY
 */
package androidx.media3.exoplayer.ima;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "androidx.media3.exoplayer.ima";
  public static final String BUILD_TYPE = "release";
}
