/*
 * Copyright 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.credentials.providerevents.exception

/** Used by the system when the request fails to reach the provider */
public class ExportCredentialsSystemErrorException(errorMessage: CharSequence? = null) :
    ExportCredentialsException(TYPE_EXPORT_CREDENTIALS_SYSTEM_ERROR_EXCEPTION, errorMessage) {
    internal companion object {
        internal const val TYPE_EXPORT_CREDENTIALS_SYSTEM_ERROR_EXCEPTION: String =
            "androidx.credentials.providerevents.exception.TYPE_EXPORT_CREDENTIALS_SYSTEM_ERROR_EXCEPTION"
    }
}
